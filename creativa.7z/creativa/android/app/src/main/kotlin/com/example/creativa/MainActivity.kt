package com.example.creativa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
